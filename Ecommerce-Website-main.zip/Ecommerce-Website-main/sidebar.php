
<nav class="w3-sidebar w3-collapse w3-white w3-animate-left" style="z-index:3;width:300px;" id="mySidebar"><br>
  <div class="w3-container w3-row">

    <div class="w3-col s8 w3-bar">
      <span style="padding-left: 15px;"><strong>Admin</strong></span><br>

    </div>
  </div>
  <hr>
  <div class="w3-container">
    <h5>Dashboard</h5>
  </div>
  <div class="w3-bar-block">
    <a href="#" class="w3-bar-item w3-button w3-padding-16 w3-hide-large w3-dark-grey w3-hover-black" onclick="w3_close()" title="close menu"><i class="fa fa-remove fa-fw"></i>  Close Menu</a>
    <a href="admin_index.php" class="w3-bar-item w3-button w3-padding w3-padding"><i class="fa fa-binoculars fa-fw"></i>  Overview</a>
    <a href="admin_list_order.php" class="w3-bar-item w3-button w3-padding"><i class="fa fa-truck fa-fw"></i> List Order</a>
    <a href="admin_products.php" class="w3-bar-item w3-button w3-padding"><i class="fa fa-eye fa-fw"></i> View Products</a>
    <a href="admin_add_product.php" class="w3-bar-item w3-button w3-padding"><i class="fa fa-cart-plus fa-fw"></i> Add Product</a>
    <a href="categories.php" class="w3-bar-item w3-button w3-padding"><i class="fa fa-bullseye fa-fw"></i> Categories</a>
    <a href="users.php" class="w3-bar-item w3-button w3-padding"><i class="fa fa-users fa-fw"></i> Users</a>
  </div>
</nav>


