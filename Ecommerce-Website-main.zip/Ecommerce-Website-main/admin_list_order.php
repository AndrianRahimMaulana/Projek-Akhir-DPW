<?php require_once("config.php"); ?>


    <?php include("admin_header.php") ?>

    <?php include("sidebar.php") ?>

        <div class="w3-overlay w3-hide-large w3-animate-opacity" onclick="w3_close()" style="cursor:pointer" title="close side menu" id="myOverlay"></div>

    <div class="w3-main" style="margin-left:300px;margin-top:43px;">

    <header class="w3-container" style="padding-top:22px">

  </header>

  <div class="w3-container">
  	<h3 class="bg"><?php display_message();?></h3>
  	<h3> List Order </h3>
  </div>

  <table>
       <tr>
       		<th></th>
               <td></td>    
           <th>Name</th>
           <td></td>    
           <th>Email</th>
           <td></td>
           <th>Address</th>
           <td></td>
           <th>Product Title</th>
           <td></td>
           <th>Total Order</th>
           <td></td>
           <th>Total Price</th>
           <td></td>
           <th>Product Image</th>
           <th></th>
           <th>Country</th>
           <td></td>
           <th>Payment Type</th>
           <td></td>
           <th>Status Order</th>

       </tr>
        <?php get_list_order(); ?>

       
   </table>