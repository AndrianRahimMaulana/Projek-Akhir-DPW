
  <div class="footer">
      <div class="container">
          <div class="row">
              <div class="footer-col1">
                 <h3>Download Our App</h3>
                  <p>Download the app for Android and iOS</p>
                  <div class="app-logo">
                      <img src="images/play-store.png">
                      <img src="images/app-store.png">
                  </div>
              </div>
              <div class="footer-col2">
                 <img src="images/logo1.png">
              </div>
              <div class="footer-col3">
                 <h3>Follow Us On</h3>
                  <ul>
                      <li>Facebook</li>
                      <li>Twitter<li>
                      <li>Instagram</li>
                      <li>YouTube</li>
                  </ul>
              </div>
          </div>
          <hr>
          <p class="copyright">Copyright 2021</p>
      </div>
      
  </div>




</body>
</html>