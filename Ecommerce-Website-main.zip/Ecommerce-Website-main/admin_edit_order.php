<?php require_once("config.php"); ?>

<?php 

  if(isset($_GET['id'])) {
    $query = query("SELECT * FROM `order` WHERE id_order = " . escape_string($_GET['id']) . " ");
    confirm($query);

    while($row = fetch_array($query)) {

        $username = escape_string($row['name']);
		$email = escape_string($row['email']);
		$address = escape_string($row['address']);
        $title = escape_string($row['product_title']);
		$total = escape_string($row['totalorder']);
		$price = escape_string($row['total_price']);
        $image = escape_string($row['product_image']);
        $country = escape_string($row['country']);
        $payment = escape_string($row['payment_type']);
        $status = escape_string($row['order_status']);


    }
    edit_order_admin();
  }

?>



    <?php include("admin_header.php") ?>

    <?php include("sidebar.php") ?>

        <div class="w3-overlay w3-hide-large w3-animate-opacity" onclick="w3_close()" style="cursor:pointer" title="close side menu" id="myOverlay"></div>

    <div class="w3-main" style="margin-left:300px;margin-top:43px;">

    <header class="w3-container" style="padding-top:22px">

  </header>

  <div class="w3-container">
  	<h3 class="bg"><?php display_message();?></h3>
  	<h3> Update Order </h3>
    <hr style="border-color: black;">
  </div>

          
           <div class="col-2" style="padding-left: 20px;">

              <div class="form-container2">
                 <div class="form-btn">
                 </div>
                 
                 <form class="" action="" method="post" enctype="multipart/form-data">

                      <div class="col-md-8">
                        
                        <div class="form-group" style="align-items: center;">
                          <label for="product-title">Nama Buyyer </label>
                          <input type="text" name="name_order" value="<?php echo $username; ?>"></label>
                      </div>

                      <br>
                      <div class="form-group">
                        <div class="col-xs-3">
                          <label for="product-price">Email</label>
                          <input type="text" name="email_order" class="form-control" size="60" value="<?php echo $email; ?>">
                        </div>
                        <br>
                        <label for="product-title">Address</label>
                           <br>
                        <textarea name="address" id="" cols="76" rows="10" class="form-control" ><?php echo $address; ?></textarea>
                    </div>

                      <br>
                      <div class="form-group">
                        <div class="col-xs-3">
                          <label for="product-price">Product Title</label>
                          <input type="text" name="product_title" class="form-control" size="60" value="<?php echo $title; ?>">
                        </div>
                        <br>
                      <div class="form-group">
                        <div class="col-xs-3">
                          <label for="product-price">Total Order</label>
                          <input type="text" name="totalorder" class="form-control" size="60" value="<?php echo $total; ?>">
                        </div>
                        <br>
                      <div class="form-group">
                        <div class="col-xs-3">
                          <label for="product-price">Total Price</label>
                          <input type="text" name="total_price" class="form-control" size="60" value="<?php echo $price; ?>">
                        </div>
                        <br>
                      <div class="form-group">
                        <div class="col-xs-3">
                          <label for="product-price">Product Image</label>
                          <input type="text" name="product_image" class="form-control" size="60" value="<?php echo $image; ?>">
                        </div>
                        <br>
                      <div class="form-group">
                        <div class="col-xs-3">
                          <label for="product-price">Country</label>
                          <input type="text" name="country" class="form-control" size="60" value="<?php echo $country; ?>">
                        </div>
                        <br>
                      <div class="form-group">
                        <div class="col-xs-3">
                          <label for="product-price">Payment Type</label>
                          <input type="text" name="payment" class="form-control" size="60" value="<?php echo $payment; ?>">
                        </div>
                        <br>
                      <div class="form-group">
                        <div class="col-xs-3">
                          <label for="product-price">Order Status</label>
                          <input type="text" name="order_status" class="form-control" size="60" value="<?php echo $status; ?>">
                        </div>
                        <div class="form-group" >
                          <div class="row">
                              <input type="submit" name="back" class="btn" value="Back">
                              <input type="submit" name="publish" class="btn" value="Publish">
                          </div>
                        
                      </div>
                     


                    <br>
                    <!-- <div class="form-group">
                        <label for="product-title">Product Quantity</label>
                           <input type="number" name="product_quantity" class="form-control"  value="<?php echo $product_quantity; ?>" >
                      </div>

                      <br>
                      <div class="form-group">
                            <label for="product-title">Product Short Description</label>
                          <input type="text" name="product_short_desc" class="form-control" value="<?php echo $product_short_desc; ?>" >
                      </div>


                      <br>
                      <div class="form-group">
                          <label for="product-title">Product Image</label>
                          <input type="file" src="uploads/<?php echo $product_image; ?>"  name="file">
                         -->
                      <!-- </div> -->

                      <br>

                        

                       </div>

            </form>
              </div>

           </div>


  </body>
</html>

