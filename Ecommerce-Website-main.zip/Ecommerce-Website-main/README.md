# Ecommerce-Website

<br>

### Description

An e-commerce music store website that sells electronic music products.

<br>

### Screenshots

**Home Page**

<img src="https://tva1.sinaimg.cn/large/008i3skNgy1gruxe565jnj30i90kjagq.jpg" alt="homepage" />

<br>
<br>

**Product Details Page**

<img src="https://tva1.sinaimg.cn/large/008i3skNgy1gruxh0khdaj60ko0jxq8202.jpg" alt="detailspage" />

<br>
<br>

**Products Page**

<img src="https://tva1.sinaimg.cn/large/008i3skNgy1gruxldon36j30vd0h17bu.jpg" alt="products" />

<br>
<br>

**Shopping Cart**

<img src="https://tva1.sinaimg.cn/large/008i3skNgy1gruxi3ycadj30xd0h1myp.jpg" alt="cart" />
